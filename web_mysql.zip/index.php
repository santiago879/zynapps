<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
echo "<h1>Bienvenido a la red social con MySQL</h1>";
echo "<p><a href='posts.php'>Publicaciones</a> | <a href='messages.php'>Mensajes</a> | <a href='friends.php'>Amigos</a> | <a href='logout.php'>Cerrar sesión</a></p>";
?>