<?php
require "db.php";
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $contenido = $_POST["contenido"];
    $stmt = $pdo->prepare("INSERT INTO posts (user_id, contenido) VALUES (?, ?)");
    $stmt->execute([$_SESSION['user_id'], $contenido]);
}
$posts = $pdo->query("SELECT p.*, u.usuario FROM posts p JOIN users u ON p.user_id=u.id ORDER BY p.id DESC")->fetchAll();
?>
<form method="post">
    <textarea name="contenido" placeholder="Escribe algo..." required></textarea>
    <button type="submit">Publicar</button>
</form>
<?php foreach ($posts as $post): ?>
    <p><b><?= htmlspecialchars($post['usuario']) ?>:</b> <?= htmlspecialchars($post['contenido']) ?></p>
<?php endforeach; ?>