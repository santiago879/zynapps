<?php
require "db.php";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $usuario = $_POST["usuario"];
    $email = $_POST["email"];
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT INTO users (usuario, email, password) VALUES (?, ?, ?)");
    $stmt->execute([$usuario, $email, $password]);
    echo "Usuario registrado correctamente. <a href='login.php'>Inicia sesión</a>";
}
?>
<form method="post">
    <input type="text" name="usuario" placeholder="Usuario" required>
    <input type="email" name="email" placeholder="Correo" required>
    <input type="password" name="password" placeholder="Contraseña" required>
    <button type="submit">Registrarse</button>
</form>