<?php
require "db.php";
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $para = $_POST["para"];
    $contenido = $_POST["contenido"];
    $stmt = $pdo->prepare("INSERT INTO messages (sender_id, receiver_id, contenido) VALUES (?, ?, ?)");
    $stmt->execute([$_SESSION['user_id'], $para, $contenido]);
}
$messages = $pdo->query("SELECT m.*, u.usuario as sender FROM messages m JOIN users u ON m.sender_id=u.id ORDER BY m.id DESC")->fetchAll();
?>
<form method="post">
    <input type="number" name="para" placeholder="ID Destinatario" required>
    <textarea name="contenido" placeholder="Mensaje..." required></textarea>
    <button type="submit">Enviar</button>
</form>
<?php foreach ($messages as $m): ?>
    <p><b><?= htmlspecialchars($m['sender']) ?> → <?= $m['receiver_id'] ?>:</b> <?= htmlspecialchars($m['contenido']) ?></p>
<?php endforeach; ?>