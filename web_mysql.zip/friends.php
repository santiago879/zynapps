<?php
require "db.php";
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $amigo = $_POST["amigo"];
    $stmt = $pdo->prepare("INSERT INTO friends (user_id, friend_id) VALUES (?, ?)");
    $stmt->execute([$_SESSION['user_id'], $amigo]);
}
$friends = $pdo->prepare("SELECT u.usuario FROM friends f JOIN users u ON f.friend_id=u.id WHERE f.user_id=?");
$friends->execute([$_SESSION['user_id']]);
$friends = $friends->fetchAll();
?>
<form method="post">
    <input type="number" name="amigo" placeholder="ID Usuario" required>
    <button type="submit">Agregar amigo</button>
</form>
<?php foreach ($friends as $f): ?>
    <p>👤 <?= htmlspecialchars($f['usuario']) ?></p>
<?php endforeach; ?>