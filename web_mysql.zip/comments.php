<?php
require "db.php";
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $post_id = $_POST["post_id"];
    $contenido = $_POST["contenido"];
    $stmt = $pdo->prepare("INSERT INTO comments (post_id, user_id, contenido) VALUES (?, ?, ?)");
    $stmt->execute([$post_id, $_SESSION['user_id'], $contenido]);
}
$comments = $pdo->query("SELECT c.*, u.usuario FROM comments c JOIN users u ON c.user_id=u.id ORDER BY c.id DESC")->fetchAll();
?>
<form method="post">
    <input type="number" name="post_id" placeholder="ID Post" required>
    <textarea name="contenido" placeholder="Comentario..." required></textarea>
    <button type="submit">Comentar</button>
</form>
<?php foreach ($comments as $c): ?>
    <p><b><?= htmlspecialchars($c['usuario']) ?>:</b> <?= htmlspecialchars($c['contenido']) ?> (en post <?= $c['post_id'] ?>)</p>
<?php endforeach; ?>